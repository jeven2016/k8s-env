##
https://codingdict.com/questions/64086
https://github.com/coreos/go-oidc
https://github.com/gophercloud/gophercloud